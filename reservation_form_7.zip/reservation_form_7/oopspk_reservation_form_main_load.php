<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
require(wp_reservation_dir."/inc/oopspk_functions.php");
require(wp_reservation_dir."/inc/oops_pk_shortcodes.php");