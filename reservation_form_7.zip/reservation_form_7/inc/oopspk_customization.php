<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
$oops_wp_reservation_label_name = get_option('oops_wp_reservation_label_name');
$oops_wp_reservation_fields_type = get_option('oops_wp_reservation_fields_type');
$oops_wp_reservation_fields_tag = get_option('oops_wp_reservation_fields_tag');
?>
    
<form method="post" action="options.php">
    <?php 
    	 
         settings_fields( 'oops-reservation-from-settings-group' ); 
         do_settings_sections( 'oops-reservation-from-settings-group' );

    ?>
   <table class="wp-list-table widefat fixed posts" style="margin-bottom:10px;">
	<thead>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th> Fields Names </th>
			<th> Fields Tags </th>
			<th> Fields Types </th>
			<th> Labels Names</th>
		</tr>
	</tfoot>
	<tbody>
		<tr>
			<td><?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field1'])); ?></td>
			<td>
				<select name="tag_field1">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_tag['field1'])); ?></option>
					<?php
				if($oops_wp_reservation_fields_tag['field1'] == 'Input'){
					echo'
					<option>Select</option>
					<option>Textarea</option>';

				}
				if($oops_wp_reservation_fields_tag['field1'] == 'Select'){
					echo'<option>Input</option>
					<option>Textarea</option>';
				}
				if($oops_wp_reservation_fields_tag['field1'] == 'Textarea'){
					echo'
					<option>Input</option>
					<option>Select</option>
					';
				}
			?>
				</select>
			</td>
			<td>
				<select name="fieldtype1">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_type['field1'])); ?></option>
<?php
					if($oops_wp_reservation_fields_type['field1'] == 'Text'){
						echo'
					<option>Email</option>
					<option>Password</option>
					<option>Number</option>
						';
					}
					if($oops_wp_reservation_fields_type['field1'] == 'Email'){
					  echo'
					    <option>Text</option>
					    <option>Password</option>
					    <option>Number</option>
						';	
					}
					if($oops_wp_reservation_fields_type['field1'] == 'Password'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Number</option>
						';		
					}
					if($oops_wp_reservation_fields_type['field1'] == 'Number'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Password</option>
						';		
					}
					?>
				</select>
			</td>
			<td>
				<input type="text" name="inputfield1" value="<?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field1'])); ?>" >
			</td>
		</tr>
		<tr>
			<td><?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field2'])); ?></td>
			<td>
				<select name="tag_field2">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_tag['field2'])); ?></option>
					<?php
				if($oops_wp_reservation_fields_tag['field2'] == 'Input'){
					echo'
					<option>Select</option>
					<option>Textarea</option>';

				}
				if($oops_wp_reservation_fields_tag['field2'] == 'Select'){
					echo'<option>Input</option>
					<option>Textarea</option>';
				}
				if($oops_wp_reservation_fields_tag['field2'] == 'Textarea'){
					echo'
					<option>Input</option>
					<option>Select</option>
					';
				}
			?>
				</select>
			</td>
			<td>
				<select name="fieldtype2">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_type['field2'])); ?></option>
					<?php
					if($oops_wp_reservation_fields_type['field2'] == 'Text'){
						echo'
					<option>Email</option>
					<option>Password</option>
					<option>Number</option>
						';
					}
					if($oops_wp_reservation_fields_type['field2'] == 'Email'){
					  echo'
					    <option>Text</option>
					    <option>Password</option>
					    <option>Number</option>
						';	
					}
					if($oops_wp_reservation_fields_type['field2'] == 'Password'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Number</option>
						';		
					}
					if($oops_wp_reservation_fields_type['field2'] == 'Number'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Password</option>
						';		
					}
					?>
				</select>
			</td>
			<td>
				<input type="text" name="inputfield2" value="<?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field2'])); ?>">
			</td>
		</tr>
		<tr>
			<td><?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field3'])); ?></td>
			<td>
				<select name="tag_field3">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_tag['field3'])); ?></option>
					<?php
				if($oops_wp_reservation_fields_tag['field3'] == 'Input'){
					echo'
					<option>Select</option>
					<option>Textarea</option>';

				}
				if($oops_wp_reservation_fields_tag['field3'] == 'Select'){
					echo'<option>Input</option>
					<option>Textarea</option>';
				}
				if($oops_wp_reservation_fields_tag['field3'] == 'Textarea'){
					echo'
					<option>Input</option>
					<option>Select</option>
					';
				}
			?>
				</select>
			</td>
			<td>
				<select name="fieldtype3">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_type['field3'])); ?></option>
					<?php
					if($oops_wp_reservation_fields_type['field3'] == 'Text'){
						echo'
					<option>Email</option>
					<option>Password</option>
					<option>Number</option>
						';
					}
					if($oops_wp_reservation_fields_type['field3'] == 'Email'){
					  echo'
					    <option>Text</option>
					    <option>Password</option>
					    <option>Number</option>
						';	
					}
					if($oops_wp_reservation_fields_type['field3'] == 'Password'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Number</option>
						';		
					}
					if($oops_wp_reservation_fields_type['field3'] == 'Number'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Password</option>
						';		
					}
					?>
				</select>
			</td>
			<td>
				<input type="text" name="inputfield3" value="<?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field3'])); ?>">
			</td>
		</tr>
		<tr>
			<td><?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field4'])); ?></td>
			<td>
				<select name="tag_field4">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_tag['field4'])); ?></option>
			<?php
				if($oops_wp_reservation_fields_tag['field4'] == 'Input'){
					echo'
					<option>Select</option>
					<option>Textarea</option>';

				}
				if($oops_wp_reservation_fields_tag['field4'] == 'Select'){
					echo'<option>Input</option>
					<option>Textarea</option>';
				}
				if($oops_wp_reservation_fields_tag['field4'] == 'Textarea'){
					echo'
					<option>Input</option>
					<option>Select</option>
					';
				}
			?>
				</select>
			</td>
			<td>
				<select name="fieldtype4">
					<option selected><?php echo esc_attr(ucwords($oops_wp_reservation_fields_type['field4'])); ?></option>
					<?php
					if($oops_wp_reservation_fields_type['field4'] == 'Text'){
						echo'
					<option>Email</option>
					<option>Password</option>
					<option>Number</option>
						';
					}
					if($oops_wp_reservation_fields_type['field4'] == 'Email'){
					  echo'
					    <option>Text</option>
					    <option>Password</option>
					    <option>Number</option>
						';	
					}
					if($oops_wp_reservation_fields_type['field4'] == 'Password'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Number</option>
						';		
					}
					if($oops_wp_reservation_fields_type['field4'] == 'Number'){
						echo'
					    <option>Text</option>
					    <option>Email</option>
					    <option>Password</option>
						';		
					}
					?>
				</select>
			</td>
			<td>
				<input type="text" name="inputfield4" value="<?php echo esc_attr(ucwords($oops_wp_reservation_label_name['field4'])); ?>">
			</td>
		</tr>
	</tbody>
</table> 
 
	
<input type="submit" name="submit_customization" id="submit" class="button button-primary" value="Save Changes"  />
</form>

<?php
if ( isset( $_GET['settings-updated'] ) ) {
      // add settings saved message with the class of "updated"
      add_settings_error( 'oopspk_messages', 'oopspk_messages', __( 'Settings Saved', 'oopspk_messages' ), 'updated' );
      }
      
      // show error/update messages
      settings_errors( 'oopspk_messages' );
?>